
  # Gamified Pharmacy Question Bank

  This is a code bundle for Gamified Pharmacy Question Bank. The original project is available at https://www.figma.com/design/SGu9vtiCuyLJldNsiltQz8/Gamified-Pharmacy-Question-Bank.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  