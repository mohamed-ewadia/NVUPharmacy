import { motion } from "motion/react";
import { Trophy, Star, TrendingUp, RotateCcw, Home, ChevronRight } from "lucide-react";

interface ResultModalProps {
  levelId: number;
  score: number;
  totalQuestions: number;
  onRetry: () => void;
  onNextLevel: () => void;
  onBackToLevels: () => void;
  hasNextLevel: boolean;
}

export function ResultModal({
  levelId,
  score,
  totalQuestions,
  onRetry,
  onNextLevel,
  onBackToLevels,
  hasNextLevel
}: ResultModalProps) {
  const percentage = score;
  const passed = percentage >= 50;
  const isExcellent = percentage >= 80;

  const getMessage = () => {
    if (isExcellent) return "Outstanding Performance! 🌟";
    if (passed) return "Great Job! 🎉";
    return "Keep Trying! 💪";
  };

  const getEncouragement = () => {
    if (isExcellent)
      return "You've mastered this level! Your pharmaceutical knowledge is exceptional.";
    if (passed)
      return "You've passed this level! You have a solid understanding of the concepts.";
    return "Don't give up! Review the material and try again. You're making progress!";
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", duration: 0.5 }}
        className="bg-gradient-to-br from-cyan-900 via-teal-800 to-cyan-950 border-2 border-white/20 rounded-3xl p-8 md:p-12 max-w-2xl w-full shadow-2xl relative overflow-hidden"
      >
        {/* Decorative Background */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              rotate: [0, 90, 0]
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
            className="absolute -top-20 -right-20 w-60 h-60 bg-cyan-500/10 rounded-full blur-3xl"
          ></motion.div>
          <motion.div
            animate={{
              scale: [1, 1.3, 1],
              rotate: [0, -90, 0]
            }}
            transition={{
              duration: 25,
              repeat: Infinity,
              ease: "linear"
            }}
            className="absolute -bottom-20 -left-20 w-60 h-60 bg-teal-500/10 rounded-full blur-3xl"
          ></motion.div>
        </div>

        {/* Content */}
        <div className="relative z-10">
          {/* Icon */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", delay: 0.2 }}
            className="flex justify-center mb-6"
          >
            <div
              className={`p-6 rounded-full ${
                passed
                  ? "bg-gradient-to-br from-green-400 to-emerald-500"
                  : "bg-gradient-to-br from-orange-400 to-red-500"
              }`}
            >
              {passed ? (
                <Trophy size={60} className="text-white" />
              ) : (
                <Star size={60} className="text-white" />
              )}
            </div>
          </motion.div>

          {/* Title */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-3xl md:text-4xl font-bold text-white text-center mb-4"
          >
            {getMessage()}
          </motion.h2>

          {/* Score */}
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            className="text-center mb-6"
          >
            <div className="inline-block bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl px-8 py-6">
              <div className="text-6xl md:text-7xl font-bold text-white mb-2">
                {percentage}%
              </div>
              <div className="text-white/70">
                {score} out of {totalQuestions} questions
              </div>
            </div>
          </motion.div>

          {/* Progress Circle */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="flex justify-center mb-6"
          >
            <svg width="200" height="200" className="transform -rotate-90">
              {/* Background Circle */}
              <circle
                cx="100"
                cy="100"
                r="80"
                fill="none"
                stroke="rgba(255,255,255,0.1)"
                strokeWidth="12"
              />
              {/* Progress Circle */}
              <motion.circle
                cx="100"
                cy="100"
                r="80"
                fill="none"
                stroke={passed ? "#10b981" : "#f97316"}
                strokeWidth="12"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 80}`}
                initial={{ strokeDashoffset: 2 * Math.PI * 80 }}
                animate={{
                  strokeDashoffset:
                    2 * Math.PI * 80 - (percentage / 100) * 2 * Math.PI * 80
                }}
                transition={{ duration: 1.5, delay: 0.6 }}
              />
            </svg>
          </motion.div>

          {/* Message */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="text-center text-white/80 text-lg mb-8 max-w-md mx-auto"
          >
            {getEncouragement()}
          </motion.p>

          {/* Level Status */}
          {passed && hasNextLevel && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="bg-green-500/20 border border-green-400/50 rounded-2xl p-4 mb-6 flex items-center gap-3"
            >
              <TrendingUp className="text-green-400" size={24} />
              <span className="text-white">
                Level {levelId + 1} unlocked! You can now advance to the next challenge.
              </span>
            </motion.div>
          )}

          {/* Actions */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <button
              onClick={onRetry}
              className="flex items-center justify-center gap-2 px-6 py-4 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold rounded-2xl transition-all"
            >
              <RotateCcw size={20} />
              Try Again
            </button>

            {passed && hasNextLevel ? (
              <button
                onClick={onNextLevel}
                className="flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-white font-bold rounded-2xl transition-all shadow-lg"
              >
                Next Level
                <ChevronRight size={20} />
              </button>
            ) : (
              <button
                onClick={onBackToLevels}
                className="flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-white font-bold rounded-2xl transition-all shadow-lg"
              >
                <Home size={20} />
                Back to Levels
              </button>
            )}
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="mt-8 grid grid-cols-3 gap-4 text-center"
          >
            <div className="bg-white/5 rounded-2xl p-4">
              <div className="text-2xl font-bold text-white mb-1">
                {score}
              </div>
              <div className="text-white/60 text-sm">Correct</div>
            </div>
            <div className="bg-white/5 rounded-2xl p-4">
              <div className="text-2xl font-bold text-white mb-1">
                {totalQuestions - score}
              </div>
              <div className="text-white/60 text-sm">Wrong</div>
            </div>
            <div className="bg-white/5 rounded-2xl p-4">
              <div className="text-2xl font-bold text-white mb-1">
                {passed ? "✓" : "✗"}
              </div>
              <div className="text-white/60 text-sm">Status</div>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
