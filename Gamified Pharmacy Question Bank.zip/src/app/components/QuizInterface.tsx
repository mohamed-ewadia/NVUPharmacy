import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Clock, CheckCircle, XCircle, ArrowRight, Home } from "lucide-react";
import { Question } from "../data/questions";

interface QuizInterfaceProps {
  levelId: number;
  questions: Question[];
  onComplete: (score: number) => void;
  onBackToLevels: () => void;
}

export function QuizInterface({
  levelId,
  questions,
  onComplete,
  onBackToLevels
}: QuizInterfaceProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [answeredQuestions, setAnsweredQuestions] = useState(0);

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  // Timer
  useEffect(() => {
    if (showExplanation) return;

    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      // Time's up - auto submit wrong answer
      handleAnswerSelect(-1);
    }
  }, [timeLeft, showExplanation]);

  const handleAnswerSelect = (answerIndex: number) => {
    if (selectedAnswer !== null) return;

    setSelectedAnswer(answerIndex);
    setShowExplanation(true);

    const isCorrect = answerIndex === currentQuestion.correctAnswer;
    if (isCorrect) {
      setScore(score + 1);
    }
    setAnsweredQuestions(answeredQuestions + 1);
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
      setTimeLeft(60);
    } else {
      // Quiz complete
      const finalScore = Math.round((score / questions.length) * 100);
      onComplete(finalScore);
    }
  };

  const isCorrect = selectedAnswer === currentQuestion.correctAnswer;
  const timeProgress = (timeLeft / 60) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-900 via-teal-800 to-cyan-950 p-4 relative overflow-hidden">
      {/* NUB Branding */}
      <div className="absolute top-4 right-4 md:top-8 md:right-8 text-white/20 font-bold text-3xl md:text-6xl">
        NUB
      </div>

      <div className="max-w-4xl mx-auto relative z-10 py-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBackToLevels}
            className="text-white/60 hover:text-white transition-colors flex items-center gap-2 mb-4"
          >
            <Home size={20} />
            Back to Levels
          </button>

          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl md:text-3xl font-bold text-white">
              Level {levelId}
            </h2>
            <div className="text-white/80">
              Question {currentQuestionIndex + 1} / {questions.length}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              className="h-full bg-gradient-to-r from-cyan-400 to-teal-500"
            ></motion.div>
          </div>
        </div>

        {/* Timer */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="mb-6 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-4"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-white">
              <Clock size={20} className={timeLeft <= 10 ? "text-red-400" : "text-cyan-400"} />
              <span className="font-bold">{timeLeft}s</span>
            </div>
            <div className="text-white/60 text-sm">
              Score: {score} / {answeredQuestions}
            </div>
          </div>
          <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
            <motion.div
              animate={{ width: `${timeProgress}%` }}
              className={`h-full ${
                timeLeft <= 10
                  ? "bg-gradient-to-r from-red-500 to-orange-500"
                  : "bg-gradient-to-r from-cyan-400 to-teal-500"
              }`}
            ></motion.div>
          </div>
        </motion.div>

        {/* Question Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestionIndex}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 md:p-8 shadow-2xl mb-6"
          >
            <h3 className="text-xl md:text-2xl text-white mb-8 leading-relaxed">
              {currentQuestion.question}
            </h3>

            {/* Options */}
            <div className="space-y-4">
              {currentQuestion.options.map((option, index) => {
                const isSelected = selectedAnswer === index;
                const isCorrectAnswer = index === currentQuestion.correctAnswer;
                const showCorrect = showExplanation && isCorrectAnswer;
                const showWrong = showExplanation && isSelected && !isCorrect;

                return (
                  <motion.button
                    key={index}
                    whileHover={!showExplanation ? { scale: 1.02 } : {}}
                    whileTap={!showExplanation ? { scale: 0.98 } : {}}
                    onClick={() => handleAnswerSelect(index)}
                    disabled={showExplanation}
                    className={`w-full text-left p-4 md:p-5 rounded-2xl border-2 transition-all ${
                      showCorrect
                        ? "bg-green-500/20 border-green-400 text-white"
                        : showWrong
                        ? "bg-red-500/20 border-red-400 text-white"
                        : isSelected
                        ? "bg-white/20 border-cyan-400 text-white"
                        : "bg-white/5 border-white/20 text-white/90 hover:bg-white/10 hover:border-white/40"
                    } ${showExplanation ? "cursor-not-allowed" : "cursor-pointer"}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="flex-1 pr-4">{option}</span>
                      {showCorrect && <CheckCircle className="text-green-400" size={24} />}
                      {showWrong && <XCircle className="text-red-400" size={24} />}
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Explanation */}
        <AnimatePresence>
          {showExplanation && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={`rounded-3xl p-6 md:p-8 mb-6 ${
                isCorrect
                  ? "bg-green-500/10 border-2 border-green-400/50"
                  : "bg-red-500/10 border-2 border-red-400/50"
              }`}
            >
              <div className="flex items-start gap-4">
                {isCorrect ? (
                  <CheckCircle className="text-green-400 flex-shrink-0 mt-1" size={28} />
                ) : (
                  <XCircle className="text-red-400 flex-shrink-0 mt-1" size={28} />
                )}
                <div className="flex-1">
                  <h4
                    className={`text-xl font-bold mb-3 ${
                      isCorrect ? "text-green-400" : "text-red-400"
                    }`}
                  >
                    {isCorrect ? "Correct! 🎉" : "Incorrect"}
                  </h4>
                  <p className="text-white/90 leading-relaxed">
                    {currentQuestion.explanation}
                  </p>
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleNext}
                className="mt-6 w-full bg-gradient-to-r from-cyan-500 to-teal-500 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-2 shadow-lg"
              >
                {currentQuestionIndex < questions.length - 1 ? (
                  <>
                    Next Question
                    <ArrowRight size={20} />
                  </>
                ) : (
                  <>
                    View Results
                    <ArrowRight size={20} />
                  </>
                )}
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
