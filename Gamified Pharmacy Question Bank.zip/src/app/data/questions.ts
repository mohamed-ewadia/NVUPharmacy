export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Level {
  id: number;
  name: string;
  questions: Question[];
}

export const LEVELS: Level[] = [
  {
    id: 1,
    name: "Level 1",
    questions: [
      {
        id: 1,
        question: "Ligand is a .................., ................... lone pair of electrons, ex ..........",
        options: [
          "Lewis base, donor, (N, O, S)",
          "Lewis base, accept, (N, O, S)",
          "Lewis acid, accept, (Ca²⁺, Mn²⁺, Pb²⁺)",
          "Lewis acid, donor, (Ca²⁺, Mn²⁺, Pb²⁺)"
        ],
        correctAnswer: 0,
        explanation: "Ligand is a Lewis base that donates lone pair of electrons. Common examples include atoms like N, O, and S."
      },
      {
        id: 2,
        question: "Metal is a .................., ................... lone pair of electrons, ex ..........",
        options: [
          "Lewis acid, donor, (N, O, S)",
          "Lewis acid, accept, (Ca²⁺, Mn²⁺, Pb²⁺)",
          "Lewis base, accept, (N, O, S)",
          "Lewis base, donor, (Ca²⁺, Mn²⁺, Pb²⁺)"
        ],
        correctAnswer: 1,
        explanation: "Metal is a Lewis acid that accepts lone pair of electrons. Common metal ions include Ca²⁺, Mn²⁺, and Pb²⁺."
      },
      {
        id: 3,
        question: "The ability of a central metal ion to form a complex increases when:",
        options: [
          "Acidity of metal ↓, Ionic size ↑, Ionic charge ↓",
          "Acidity of metal ↑, Ionic size ↓, Ionic charge ↑",
          "Acidity of metal ↓, Ionic size ↓, Ionic charge ↑",
          "Acidity of metal ↑, Ionic size ↑, Ionic charge ↓"
        ],
        correctAnswer: 1,
        explanation: "Complex formation ability increases when: Acidity of metal increases, Ionic size decreases, and Ionic charge increases."
      },
      {
        id: 4,
        question: "The ability of a ligand to form a complex increases when:",
        options: [
          "Basicity of ligand ↓, chelate effect ↓, size of ligand ↓, steric effect ↓",
          "Basicity of ligand ↑, chelate effect ↑, size of ligand ↑, steric effect ↑",
          "Basicity of ligand ↑, chelate effect ↑, size of ligand ↓, steric effect ↓",
          "Basicity of ligand ↓, chelate effect ↑, size of ligand ↑, steric effect ↓"
        ],
        correctAnswer: 1,
        explanation: "Ligand's ability to form complexes increases when: Basicity increases, chelate effect increases, size increases, and steric effect increases."
      },
      {
        id: 5,
        question: "Which compound has the strongest electron-donating power?",
        options: [
          "EBT (Eriochrome Black T)",
          "EDTA",
          "Both have equal donating power",
          "Neither acts as an electron donor"
        ],
        correctAnswer: 1,
        explanation: "EDTA has the strongest electron-donating power among common chelating agents."
      },
      {
        id: 6,
        question: "Why is EDTA used as a preservative?",
        options: [
          "It kills bacteria directly by destroying cell walls",
          "It acts as a chelating agent for metal ions, preventing spoilage caused by bacteria and fungi",
          "It increases the pH to inhibit microbial growth",
          "It acts as an oxidizing agent"
        ],
        correctAnswer: 1,
        explanation: "EDTA preserves by chelating metal ions, which prevents bacterial and fungal growth that depends on these metals."
      },
      {
        id: 7,
        question: "When dispensing an antibiotic like tetracycline, which instruction should you give to the patient?",
        options: [
          "Take with milk to reduce stomach upset",
          "Take doses on time, drink plenty of water, avoid dairy products",
          "Take only once a day regardless of dose",
          "Avoid water for 2 hours after taking"
        ],
        correctAnswer: 1,
        explanation: "Tetracycline should be taken on time with plenty of water, and dairy products should be avoided as they can chelate with the antibiotic."
      },
      {
        id: 8,
        question: "In complexometry, why is the disodium salt of EDTA used instead of the parent acid?",
        options: [
          "It is more stable as a chelating agent",
          "It is more soluble in water",
          "It is more selective for metal ions",
          "It acts as a buffer"
        ],
        correctAnswer: 1,
        explanation: "The disodium salt of EDTA is used because it is more soluble in water compared to the parent acid form."
      },
      {
        id: 9,
        question: "Which statement is correct about EDTA?",
        options: [
          "EDTA is a highly selective reagent for Ca²⁺ only",
          "EDTA is not a selective reagent",
          "EDTA reacts only with transition metals",
          "EDTA does not form stable complexes"
        ],
        correctAnswer: 1,
        explanation: "EDTA is not a selective reagent - it can form complexes with many different metal ions."
      },
      {
        id: 10,
        question: "Why is a buffer solution used in complexometric titration with EDTA?",
        options: [
          "To increase the temperature of the reaction",
          "To adjust the pH so that the indicator is sensitive only to the metal ion",
          "To speed up the titration process",
          "To precipitate the metal ion before titration"
        ],
        correctAnswer: 1,
        explanation: "Buffer solution adjusts and maintains pH to ensure the indicator is sensitive only to the metal ion being titrated."
      },
      {
        id: 11,
        question: "Which complex is more stable in EDTA titration?",
        options: [
          "Metal-indicator complex",
          "Metal-EDTA complex",
          "Indicator-EDTA complex",
          "Both are equally stable"
        ],
        correctAnswer: 1,
        explanation: "The Metal-EDTA complex is more stable than the metal-indicator complex, which allows the titration to work properly."
      }
    ]
  },
  {
    id: 2,
    name: "Level 2",
    questions: [
      {
        id: 1,
        question: "Which indicators are used to determine the concentration of Ca²⁺?",
        options: [
          "Phenolphthalein and methyl orange",
          "Murexide and Hydroxy Naphthol",
          "EBT and thymol blue",
          "Bromocresol green and starch"
        ],
        correctAnswer: 1,
        explanation: "Murexide and Hydroxy Naphthol are the appropriate indicators for Ca²⁺ determination."
      },
      {
        id: 2,
        question: "In alkalimetric titration of a metal solution, what must be done before titration?",
        options: [
          "The solution must be heated to boiling",
          "The solution must be accurately neutralized",
          "The solution must be filtered",
          "The solution must be diluted with alcohol"
        ],
        correctAnswer: 1,
        explanation: "Before alkalimetric titration, the metal solution must be accurately neutralized."
      },
      {
        id: 3,
        question: "What is the main role of a buffer in complexometric titration?",
        options: [
          "To increase the formation of metal-hydroxide complexes",
          "To consume released protons (H⁺) and keep pH constant",
          "To act as an indicator for the endpoint",
          "To oxidize the metal ion"
        ],
        correctAnswer: 1,
        explanation: "The buffer consumes released protons (H⁺) during the reaction and maintains a constant pH throughout the titration."
      },
      {
        id: 4,
        question: "A 4-year-old child presents with abdominal pain, constipation, and developmental delay. Blood lead level (Pb²⁺) is requested. The lab uses a complexometric method with EDTA at pH 5 (hexamine buffer). Which indicator is most suitable?",
        options: [
          "Eriochrome Black T",
          "Murexide",
          "Xylenol Orange",
          "Phenolphthalein"
        ],
        correctAnswer: 2,
        explanation: "Xylenol Orange is the most suitable indicator for lead (Pb²⁺) determination at pH 5 with hexamine buffer."
      },
      {
        id: 5,
        question: "A hospital lab needs to measure nickel (Ni²⁺) levels in a patient with suspected metal toxicity. They use murexide indicator. At which pH and buffer should they work to get the correct free indicator color?",
        options: [
          "pH = 12 (8% NaOH) → Bluish violet",
          "pH = 10 (ammonia buffer) → Violet",
          "pH = 7 (phosphate buffer) → Red",
          "pH = 2 (nitric acid) → Orange"
        ],
        correctAnswer: 1,
        explanation: "For nickel determination with murexide, pH 10 (ammonia buffer) gives a violet color for the free indicator."
      },
      {
        id: 6,
        question: "Which of the following is the most appropriate reason for using a back-titration method for Al³⁺ determination?",
        options: [
          "Al³⁺ forms a colorless complex with EDTA",
          "Al³⁺ blocks the indicator and reacts slowly with EDTA",
          "Al³⁺ does not react with EDTA at all",
          "Al³⁺ precipitates at pH 10 as Al(OH)₃"
        ],
        correctAnswer: 1,
        explanation: "Back-titration is used for Al³⁺ because it blocks the indicator and reacts slowly with EDTA, making direct titration impractical."
      },
      {
        id: 7,
        question: "In the indirect determination of Ag⁺ using the tetracyanonickelate method, why is 8% NaOH (pH 12) not used?",
        options: [
          "Because Ag⁺ would precipitate as AgOH",
          "Because EDTA decomposes at pH 12",
          "Because Ni²⁺ would precipitate as Ni(OH)₂",
          "Because murexide indicator is not stable at pH 12"
        ],
        correctAnswer: 2,
        explanation: "pH 12 is not used because Ni²⁺ would precipitate as Ni(OH)₂, interfering with the determination."
      },
      {
        id: 8,
        question: "In a displacement titration, a metal sample (e.g., Hg²⁺) is reacted with standard Mg-EDTA complex. This method is suitable only if:",
        options: [
          "The metal-EDTA complex is less stable than Mg-EDTA",
          "The metal-EDTA complex is more stable than Mg-EDTA",
          "The metal forms a colored complex with EDTA",
          "The metal does not react with the indicator at any pH"
        ],
        correctAnswer: 1,
        explanation: "Displacement titration works only when the metal-EDTA complex is more stable than Mg-EDTA, allowing the displacement to occur."
      },
      {
        id: 9,
        question: "Which of the following correctly describes the ionization state and color of Eriochrome Black T (H₃In) at pH > 11?",
        options: [
          "H₂In⁻, Red",
          "HIn²⁻, Blue",
          "In³⁻, Orange",
          "H₄In⁻, Reddish violet"
        ],
        correctAnswer: 2,
        explanation: "At pH > 11, Eriochrome Black T exists as In³⁻ and shows an orange color."
      },
      {
        id: 10,
        question: "Cyanide ion (CN⁻) is used as a masking agent. Which set of ions forms very stable cyanide complexes and can thus be masked?",
        options: [
          "Ca²⁺, Mg²⁺, Pb²⁺",
          "Cd²⁺, Zn²⁺, Cu²⁺",
          "Mn²⁺, Pb²⁺, Mg²⁺",
          "Al³⁺, Fe³⁺, Ca²⁺"
        ],
        correctAnswer: 1,
        explanation: "Cd²⁺, Zn²⁺, and Cu²⁺ form very stable cyanide complexes, making them ideal candidates for masking."
      },
      {
        id: 11,
        question: "A patient's urine sample needs analysis for lead (Pb²⁺) exposure. The analyst decides to use direct titration with EDTA at pH = 5 adjusted by hexamine. Which indicator is most appropriate according to the lecture?",
        options: [
          "Eriochrome Black T",
          "Murexide",
          "Xylenol Orange",
          "Dithizone"
        ],
        correctAnswer: 2,
        explanation: "Xylenol Orange is the most appropriate indicator for lead analysis at pH 5 with hexamine buffer."
      }
    ]
  },
  {
    id: 3,
    name: "Level 3",
    questions: [
      {
        id: 1,
        question: "Oxidation is defined as:",
        options: [
          "Gain of electrons",
          "Loss of electrons",
          "Gain of hydrogen"
        ],
        correctAnswer: 1,
        explanation: "Oxidation is defined as the loss of electrons from a chemical species."
      },
      {
        id: 2,
        question: "Reduction is defined as the:",
        options: [
          "Increase in oxidation number",
          "Decrease in oxidation number",
          "Neutralization"
        ],
        correctAnswer: 1,
        explanation: "Reduction is defined as the decrease in oxidation number of a chemical species."
      },
      {
        id: 3,
        question: "An 'Oxidizing agent' is also known as an:",
        options: [
          "Reductant",
          "Oxidant",
          "Catalyst"
        ],
        correctAnswer: 1,
        explanation: "An oxidizing agent is also called an oxidant - it accepts electrons and causes oxidation in other species."
      },
      {
        id: 4,
        question: "Oxidation and reduction reactions occur:",
        options: [
          "Independently",
          "Simultaneously",
          "In different times"
        ],
        correctAnswer: 1,
        explanation: "Oxidation and reduction reactions always occur simultaneously - when one species is oxidized, another must be reduced."
      },
      {
        id: 5,
        question: "The oxidation number of a free element (like Zn or S) is:",
        options: [
          "+1",
          "-1",
          "Zero"
        ],
        correctAnswer: 2,
        explanation: "Free elements in their natural state always have an oxidation number of zero."
      },
      {
        id: 6,
        question: "The oxidation number of Oxygen is -1 in:",
        options: [
          "Water (H₂O)",
          "Peroxides (H₂O₂)",
          "Potassium Permanganate (KMnO₄)"
        ],
        correctAnswer: 1,
        explanation: "In peroxides like H₂O₂, oxygen has an oxidation number of -1 instead of the usual -2."
      },
      {
        id: 7,
        question: "Hydrogen usually has an oxidation number of +1, EXCEPT in:",
        options: [
          "Water (H₂O)",
          "Metal hydrides (NaH)",
          "Acids (HCl)"
        ],
        correctAnswer: 1,
        explanation: "In metal hydrides like NaH, hydrogen has an oxidation number of -1 instead of +1."
      },
      {
        id: 8,
        question: "Which element has an oxidation number of -1 in ALL of its compounds?",
        options: [
          "Oxygen",
          "Chlorine",
          "Fluorine"
        ],
        correctAnswer: 2,
        explanation: "Fluorine always has an oxidation number of -1 in all its compounds because it is the most electronegative element."
      },
      {
        id: 9,
        question: "What is the oxidation number of Sulfur (S) in the sulfate ion (SO₄²⁻)?",
        options: [
          "+4",
          "+6",
          "-2"
        ],
        correctAnswer: 1,
        explanation: "In the sulfate ion (SO₄²⁻), sulfur has an oxidation number of +6."
      },
      {
        id: 10,
        question: "In KMnO₄, the oxidation number of Manganese (Mn) is:",
        options: [
          "+2",
          "+4",
          "+7"
        ],
        correctAnswer: 2,
        explanation: "In potassium permanganate (KMnO₄), manganese has an oxidation number of +7."
      },
      {
        id: 11,
        question: "The oxidation number of Nitrogen (N) in the nitrate ion (NO₃⁻) is:",
        options: [
          "+5",
          "+3",
          "-3"
        ],
        correctAnswer: 0,
        explanation: "In the nitrate ion (NO₃⁻), nitrogen has an oxidation number of +5."
      },
      {
        id: 12,
        question: "Which of the following is an example of oxidation in daily life?",
        options: [
          "Darkening of sliced fruits",
          "Dissolving salt in water",
          "Freezing water"
        ],
        correctAnswer: 0,
        explanation: "Darkening of sliced fruits is caused by oxidation of phenolic compounds when exposed to air."
      },
      {
        id: 13,
        question: "Silver-plating is an example of which process?",
        options: [
          "Oxidation of silver",
          "Reduction of silver ions",
          "Neutralization"
        ],
        correctAnswer: 1,
        explanation: "Silver-plating involves the reduction of silver ions (Ag⁺) to metallic silver (Ag⁰)."
      },
      {
        id: 14,
        question: "What can be added to cut fruit to slow down its oxidation?",
        options: [
          "Boiling water",
          "Lemon juice",
          "Vinegar"
        ],
        correctAnswer: 1,
        explanation: "Lemon juice contains vitamin C (ascorbic acid), an antioxidant that slows down oxidation of cut fruits."
      },
      {
        id: 15,
        question: "A clinical pharmacist is asked why N-acetylcysteine (NAC) is given in paracetamol overdose?",
        options: [
          "NAC directly binds to acetaminophen in the blood",
          "NAC is a strong oxidizing agent that destroys the toxin",
          "NAC replenishes glutathione, which reduces the toxic metabolite NAPQI",
          "NAC increases urine flow to excrete the drug faster"
        ],
        correctAnswer: 2,
        explanation: "NAC replenishes glutathione stores, which is essential for reducing and neutralizing the toxic metabolite NAPQI formed from paracetamol."
      },
      {
        id: 16,
        question: "While preparing an IV infusion of ferrous sulfate (Fe²⁺), the solution turns yellow-brown after one hour. What is the correct chemical explanation?",
        options: [
          "Reduction of Fe³⁺ to Fe²⁺ by oxygen",
          "Oxidation of Fe²⁺ to Fe³⁺",
          "Formation of a colored complex with sodium chloride",
          "Thermal decomposition of the solution"
        ],
        correctAnswer: 1,
        explanation: "The yellow-brown color indicates oxidation of ferrous ions (Fe²⁺) to ferric ions (Fe³⁺), typically caused by exposure to oxygen."
      }
    ]
  }
];
